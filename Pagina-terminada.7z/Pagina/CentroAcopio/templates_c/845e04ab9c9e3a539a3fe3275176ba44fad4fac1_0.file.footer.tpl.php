<?php
/* Smarty version 3.1.33, created on 2021-05-26 09:01:02
  from 'C:\xampp\htdocs\proyectos\MetodologiasGrupo12\Pagina\CentroAcopio\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_60adf22ef22731_51863650',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '845e04ab9c9e3a539a3fe3275176ba44fad4fac1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\proyectos\\MetodologiasGrupo12\\Pagina\\CentroAcopio\\templates\\footer.tpl',
      1 => 1622012371,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60adf22ef22731_51863650 (Smarty_Internal_Template $_smarty_tpl) {
?></main>
    <footer class="page-footer dark" style="background-color: rgb(34 36 37);">
        <div class="footer-copyright">
            <p style="height: 12px;">© 2018 Cooperativa de Recuperadores Urbanos de Tandil</p>
        </div>
    </footer>
    <?php echo '<script'; ?>
 src="assets/js/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="assets/bootstrap/js/bootstrap.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="assets/js/smoothproducts.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="assets/js/theme.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
