<?php


class CentroModel
{

  function __construct()
  {
    $this->db = new PDO('mysql:host=localhost;'
    .'dbname=centrodeacopio;charset=utf8'
    , 'root', '');
  }

  function GetMateriales(){
    $sentencia = $this->db->prepare( "select * from materiales");
    $sentencia->execute();
    return $sentencia->fetchAll(PDO::FETCH_ASSOC);
  }


  function AgregarPedido($nombre, $volumen){
    $sentencia = $this->db->prepare("INSERT INTO `pedidos`( `id_usuario`, `volumen`) VALUES (?,?)");
    $sentencia->execute(array($nombre,$volumen));
  }

  private function uploadImage($image){
    $target = "../CentroAcopio/Imagenes/" . uniqid() . "." . strtolower(pathinfo($image['name'], PATHINFO_EXTENSION));  
    move_uploaded_file($image['tmp_name'], $target);
    return $target;
}

  public function addImages($id,$image = null){
    $pathImg = null;
    $pathImg = $this->uploadImage($image);
        if ($image){
        $sentencia = $this->db->prepare("INSERT INTO imagen(id_usuario,direccion) VALUES(?,?)");
        $sentencia->execute(array($id,$pathImg));
    }
}
}


 ?>
